<h1>Olá Halley</h1>
<a href="/">Voltar para Home</a><?php /**PATH C:\wamp64\www\app-mvc-crud\resources\views/halley.blade.php ENDPATH**/ ?>